from collections import Counter
import heapq
import random
import time
import matplotlib.pyplot as plt


def construir_arbol_huffman(frecuencias):
    heap = [(frecuencia, str(nodo), nodo) for nodo, frecuencia in frecuencias.items()]
    heapq.heapify(heap)

    while len(heap) > 1:
        freq1, _, nodo1 = heapq.heappop(heap)
        freq2, _, nodo2 = heapq.heappop(heap)

        nuevo_nodo = (freq1 + freq2, str(nodo1) + str(nodo2), (nodo1, nodo2))
        heapq.heappush(heap, nuevo_nodo)

    return heap[0][0], heap[0][2]


def generar_codigos(nodo, codigo_actual="", codigos={}):
    if isinstance(nodo, str):
        codigos[nodo] = codigo_actual
        return codigos

    if len(nodo) == 2:
        izquierda, derecha = nodo
        generar_codigos(izquierda, codigo_actual + "0", codigos)
        generar_codigos(derecha, codigo_actual + "1", codigos)

    return codigos


def huffman(texto):
    frecuencias = Counter(texto)
    _, arbol_huffman = construir_arbol_huffman(frecuencias)
    codigos = generar_codigos(arbol_huffman)
    return codigos



def generar_texto_aleatorio(longitud):
   
    return ''.join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=longitud))


tamaños = range(1, 1000)
tiempos = []

for tamaño in tamaños:
    texto = generar_texto_aleatorio(tamaño)
    print(texto)
    inicio = time.time()
    huffman(texto)
    fin = time.time()
    tiempos.append(fin - inicio)
 
plt.figure(figsize=(10, 6))
plt.plot(tamaños, tiempos, marker='o', label="Tiempo de ejecución")
plt.title("Tiempo de ejecución del algoritmo de Huffman")
plt.xlabel("Tamaño del texto")
plt.ylabel("Tiempo (segundos)")
plt.grid()
plt.legend()
plt.show()
