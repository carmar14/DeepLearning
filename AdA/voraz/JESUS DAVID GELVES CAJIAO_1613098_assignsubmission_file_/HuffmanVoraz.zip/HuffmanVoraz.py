import heapq

class HuffmanNode:
    """
    Inicializa un nodo del árbol de Huffman.
    - freq: frecuencia asociada al nodo.
    - char: caracter asociado al nodo.
    - left: hijo izquierdo (subárbol izquierdo).
    - right: hijo derecho (subárbol derecho).
    """
    def __init__(self, freq, char=None, left=None, right=None):
        self.freq = freq
        self.char = char
        self.left = left
        self.right = right


    def __lt__(self, other):
        """
        Define el comportamiento de comparación entre nodos, esto para que la cola de prioridad
        funcione como debe ser.
        """
        return self.freq < other.freq

def huffman(C):
    """
    Algoritmo de Huffman para construir un árbol binario a partir de una lista de caracteres y sus frecuencias.
    
    - C: es una lista de tuplas, donde cada tupla contiene una frecuencia y un caracter.
    
    Este devuelve la raiz del arbol de huffman construido
    """
    Q = [HuffmanNode(freq, char) for freq, char in C]
    heapq.heapify(Q)
    

    while len(Q) > 1:
        
        x = heapq.heappop(Q) # Trae el nodo de menor frecuencia del lado izquierdo
        y = heapq.heappop(Q) # Trae el nodo de menor frecuencia del lado derecho
        

        f = x.freq + y.freq # Calcula la frecuencia del nuevo nodo
        huffman_tree = HuffmanNode(f, left=x, right=y) # Crea el nuevo nodo
       
        heapq.heappush(Q, huffman_tree) # Inserta el nuevo nodo en la cola
    
    
    return Q[0]


def generate_codes(node, prefix="", code_map=None):
    """
    Genera los códigos de Huffman asociados a cada carácter del árbol.
    Utiliza una estrategia de recorrido recursivo del árbol binario.
    
    - node: Nodo actual en el árbol de Huffman.
    - prefix: Prefijo que se está construyendo (cadena de bits "0" y "1").
    - code_map: Diccionario donde se almacenan los códigos de Huffman generados.
    
    Retorna:
    - Diccionario que asocia cada carácter a su código de Huffman.
    """
    if code_map is None:
        code_map = {}
    
    
    if node.char is not None:
        code_map[node.char] = prefix # Si es una hoja, agregar el prefijo al diccionario
    else:
      
        generate_codes(node.left, prefix + "0", code_map) # Recursivamente generar códigos para los subárboles izquierdo y derecho
        generate_codes(node.right, prefix + "1", code_map) 
    
    return code_map


if __name__ == "__main__":

    characters = [(1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')]
    

    huffman_tree = huffman(characters) 

    huffman_codes = generate_codes(huffman_tree)
    print("Huffman Codes:")
    for char, code in huffman_codes.items():
        print(f"'{char}': {code}")
